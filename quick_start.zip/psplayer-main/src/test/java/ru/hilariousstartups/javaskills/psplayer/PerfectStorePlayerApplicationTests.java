package ru.hilariousstartups.javaskills.psplayer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class PerfectStorePlayerApplicationTests {

//	@Test
	void contextLoads() {
	}

}
